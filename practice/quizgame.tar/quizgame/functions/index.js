const functions = require('firebase-functions');
const PubSub = require('@google-cloud/pubsub');
const admin = require('firebase-admin')
const Firestore = require('@google-cloud/firestore')
admin.initializeApp()

const db = admin.firestore()

exports.answerSubmit = functions.https.onCall((data, context) => {
    var userDoc = admin.firestore().collection('users').doc(context.auth.token.user_id)
    db.collection('questions').doc(data.question.questionId).collection('correctAnswer').get().then((result) => {
        var correctAnswer = result.docs[0].data()
        console.log(`correct answer given? ${correctAnswer.answer} === ${data.answer}: ${correctAnswer.answer === data.answer}`)
        data.isAnswerCorrect = correctAnswer.answer === data.answer
        userDoc.set(context.auth.token)
        userDoc.collection('answers').doc().set(data)
        return data
    }).catch((err) => {
        console.error(`An error occurred: ${err}`)
    })

    return {
       message: 'Your answer has been recorded.'
    }
})

const pubsubClient = new PubSub(); 

// Publish a message to Cloud Pub/Sub topic
// https://firebase.google.com/docs/functions/firestore-events
exports.publishMessageToTopic = functions.firestore.document('users/{userId}/answers/{answerId}').onCreate((snap,context) => {
  console.log(`context.params.userId=${context.params.userId} context.params.answerId=${context.params.answerId}`);

  //add the userId to the object
  let answerDocument = Object.assign({}, snap.data() );
  answerDocument.userId=context.params.userId;
  
  // convert the answerDocument to data buffer
  const answerDocumentString=JSON.stringify(answerDocument);
  console.log(`answerDocumentString=${answerDocumentString}`);
  const dataBuffer = Buffer.from(answerDocumentString);

  // The name for the new topic
  const topicName = 'triviagameevents';
 
  // Creates the new topic
  return pubsubClient
    .topic(topicName)
    .publisher()
    .publish(dataBuffer)
    .then(messageId => {
      console.log(`Message ${messageId} published.`);
      return messageId;
    })
    .catch(err => {
      console.error('ERROR:', err);
    });
});
