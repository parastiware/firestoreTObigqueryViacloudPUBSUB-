const fs = require('fs');
const path = require('path');
const Firestore = require('@google-cloud/firestore');
const _ = require('underscore')

const Entities = require('html-entities').AllHtmlEntities;
const entities = new Entities();

const firestore = new Firestore({
});

var coll = firestore.collection('questions')

//expecting one optional argument
const filename = process.argv[2] || path.join(__dirname,'questions.json');
console.log(`Reading from ${filename}`);
const Questions = JSON.parse(fs.readFileSync(filename, 'utf8'));

var uniqueQuestions = _.uniq(Questions.questions, function (value) {
    return value.question
})
var sortedQuestions = _.sortBy(uniqueQuestions, function (value) {
    if (value.difficulty === "easy") {
        return 0
    } else if (value.difficulty === "medium") {
        return 1
    } else if (value.difficulty === "hard") {
        return 2
    }
})
console.log(_.size(uniqueQuestions))

sortedQuestions.forEach((q,i) => {
    var choices = q.incorrect_answers
    choices.push(q.correct_answer)

    var difficulty
    if (q.difficulty === "easy") {
        difficulty = 0
    } else if (q.difficulty === "medium") {
        difficulty = 1
    } else if (q.difficulty === "hard") {
        difficulty = 2
    }


    coll.doc(`${i}`).set({
        choices: _.shuffle(_.map(choices, entities.decode)),
        question: entities.decode(q.question),
        type: q.type,
        difficulty: difficulty,
        dateAdded: Date.now(),
        questionId: `${i}`
    }).then((res) => {
        console.log(res)
    }).catch((e) => {
        console.log(`error: ${e}`)
    })

    coll.doc(`${i}`).collection('correctAnswer').doc().set({answer: entities.decode(q.correct_answer)})

   console.log(q)
})
