<template lang='html'>
  <div>
    <span class="md-display-2 md-alignment-top-center">Hello! Would you like to play a game? Sign in to play!</span>
    <div id='firebaseui-auth-container'></div>
  </div>
</template>

<script>
import firebase from 'firebase'
import firebaseui from 'firebaseui'

export default {
  name: 'Auth',
  mounted () {
    var uiConfig = {
      callbacks: {
        signInSuccessWithAuthResult: function (authResult, redirectUrl) {
          return true
        }
      },
      signInSuccessUrl: '/question',
      signInOptions: [
        {
          provider: firebase.auth.GoogleAuthProvider.PROVIDER_ID,
          customParameters: {
            prompt: 'select_account'
          }
        }
      ]
    }
    var ui = new firebaseui.auth.AuthUI(firebase.auth())
    ui.start('#firebaseui-auth-container', uiConfig)
  }
}
</script>
