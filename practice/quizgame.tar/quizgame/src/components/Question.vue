<template>
  <div id="trivia" class="md-layout md-alignment-top-center">
    <div class='question md-layout-item md-size-95'>
      <md-card v-if="question">
          <md-card-header></md-card-header>
              <md-card-content>
                  <md-badge class="md-square" :md-content="difficulty"/>
                    <span ref="question" class="md-display-1">
                        {{question.question}}
                    </span>
              </md-card-content>
          <md-card-actions>
              <md-button v-on:click="answerSubmit(choice)" ref="choice" 
                v-for="(choice,idx) in question.choices" :key="idx" :md-ripple="false" class="md-raised md-primary">{{choice}}</md-button>
          </md-card-actions>
      </md-card>
      <md-snackbar md-position="center" :md-duration=5000 :md-active.sync="showSnackbar" md-persistent>
        <span>You've already answered this question!</span>
      </md-snackbar>
    </div>
    <div class='answers md-layout-item md-size-90'>
      <md-card class="md-card-answer" v-for="(answer,idx) in userAnswers" :key="idx">
        <md-card-header>
          <div class="md-body-2">{{answer.question.question}}</div>
        </md-card-header>

        <md-card-content>
        </md-card-content>

        <md-card-actions class="md-alignment-bottom-right">
          <span class="md-body-2">{{answer.answer}}</span>
          <i class="material-icons">
            {{answer.isAnswerCorrect ? "check" : "close"}}
          </i>
        </md-card-actions>
      </md-card>
    </div>
  </div>
</template>

<script>
import {db} from '../main'
import firebase from 'firebase'
import router from '../router'

export default {
  name: 'question',
  data () {
    return {
      user: {},
      question: null,
      userAnswers: null,
      createdDate: null,
      showSnackbar: false
    }
  },
  created () {
    this.user = firebase.auth().currentUser
    this.createdDate = Date.now()
  },
  computed: {
    percentage: function () {
      var correctCount = 0.0
      var totalCount = 0.0
      for (var answer of this.userAnswers) {
        if (answer.isAnswerCorrect) {
          correctCount += 1
        }
        totalCount += 1
      }
      return ((correctCount / totalCount) * 100).toFixed(1) + '%'
    },
    difficulty: function () {
      if (this.question.difficulty === 0) {
        return 'easy'
      } else if (this.question.difficulty === 1) {
        return 'medium'
      } else if (this.question.difficulty === 2) {
        return 'hard'
      }
    }
  },
  watch: {
    '$route.params.id': function (id) {
      console.log(`in watch: ${this.$route.params.id}`)
      if (this.$route.params.id) {
        db.collection('questions').doc(this.$route.params.id).get().then((doc) => {
          this.question = doc.data()
          this.$refs.choice.forEach(function (ref) {
            ref.$el.disabled = false
          })
        })
      }
    }
  },
  firestore () {
    var questionRef = db.collection('questions').doc('0')
    // if no params are set
    if (this.$route.params.id === undefined) {
      console.log('no parameters. Has the user answered any questions previously?')
      // see if we can find the last question the user answered
      db.collection('users').doc(firebase.auth().currentUser.uid).collection('answers').orderBy('answerSubmitDate', 'desc').limit(1).get().then((result) => {
        if (result.docs.length > 0) {
          this.nextQuestion(result.docs[0].data())
        }
      })
    } else {
      console.log(`params.id = ${this.$route.params.id}`)
      questionRef = db.collection('questions').doc(this.$route.params.id)
      questionRef.get().then((q) => {
        console.log(`got question with ID ${q.questionId}`)
      })
    }

    return {
      question: questionRef,
      userAnswers: db.collection('users').doc(firebase.auth().currentUser.uid)
        .collection('answers').orderBy('answerSubmitDate', 'desc')
    }
  },
  methods: {
    nextQuestion (questionDoc) {
      console.log(questionDoc)
      var query = db.collection('questions').orderBy('questionId').startAfter(questionDoc.questionId).limit(1)
      query.get().then((r) => {
        console.log(r)
        if (!r.empty) {
          console.log(r.docs[0])
          var nextQuestionId = r.docs[0].id
          console.log(`push to ${nextQuestionId}`)
          router.push(`/question/${nextQuestionId}`)
        } else {
          router.push(`/the/end`)
        }
      })
    },
    answerSubmit (answer) {
      var refs = this.$refs
      var submitAnswerFunction = firebase.functions().httpsCallable('answerSubmit')
      refs.choice.forEach(function (ref) {
        ref.$el.disabled = true
      })

      db.collection('users').doc(this.user.uid).collection('answers')
        .where('questionId', '==', this.question.questionId).get().then((result) => {
          if (result.empty === false) {
            console.log(`already answered ${this.question.questionId}`)
            this.showSnackbar = true
          }
        })

      submitAnswerFunction({
        userId: this.user.uid,
        answer: answer,
        questionId: this.question.questionId,
        question: this.question,
        answerSubmitDate: Date.now(),
        pageCreatedDate: this.createdDate}).then((result) => {
          db.collection('users').doc(this.user.uid).set({
            lastQuestionAnswered: this.question.questionId,
            lastQuestionAnsweredTimestamp: new Date()
          }, { merge: true })
          this.nextQuestion(this.question)
        })
      .catch(function (error) {
        console.log(error)
      })
    },
    userSignOut () {
      this.$store.dispatch('userSignOut')
    }
  }
}
</script>

<!-- Add 'scoped' attribute to limit CSS to this component only -->
<style scoped>
  .md-card-answer {
    width: 320px;
    min-height: 190px;
    margin: 4px;
    display: inline-block;
    vertical-align: top;
  }
</style>
