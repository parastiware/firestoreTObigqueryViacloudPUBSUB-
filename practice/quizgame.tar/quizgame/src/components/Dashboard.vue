<template>
    <div>
        <iframe src='https://googlecloud.looker.com/embed/public/looks/tsBvBbrmXVpJpvFdFzs2xnPJycqwxZBh' width=800 height=800 frameborder='0'></iframe>
    </div>
</template>

<script>
</script>

<style>
</style>
