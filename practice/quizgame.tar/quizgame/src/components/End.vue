<template>
<div>
    <h1>You Finished! &#x1F389;</h1>
    <span>You got {{percentage}} of {{userAnswers.length}} questions right. {{completionMessage}}</span>
</div>
</template>

<script>
import {db} from '../main'
import firebase from 'firebase'

export default {
  name: 'question',
  data () {
    return {
      user: {},
      userAnswers: null
    }
  },
  created () {
    this.user = firebase.auth().currentUser
  },
  computed: {
    totalCorrect: function () {
      var correctCount = 0.0
      for (var answer of this.userAnswers) {
        if (answer.isAnswerCorrect) {
          correctCount += 1
        }
      }
      return correctCount
    },
    percentage: function () {
      var totalCount = this.userAnswers.length
      return ((this.totalCorrect / totalCount) * 100).toFixed(1)
    },
    completionMessage: function () {
      if (this.percentage > 90) {
        return 'You get an A! Excellent work!!'
      } else if (this.percentage >= 80) {
        return 'Nice job, you get a B!'
      } else if (this.percentage >= 70) {
        return 'We grade your performance a C; not bad!'
      } else if (this.percentage < 70) {
        return 'Hey, you did alright! Thanks for playing!'
      }
    }
  },
  firestore () {
    return {
      userAnswers: db.collection('users').doc(firebase.auth().currentUser.uid)
        .collection('answers').orderBy('answerSubmitDate', 'desc')
    }
  }
}
</script>

<style>
</style>