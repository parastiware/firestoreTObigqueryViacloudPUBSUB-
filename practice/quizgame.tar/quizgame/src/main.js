// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import firebase from 'firebase/app'
import 'firebase/firestore'
import 'firebaseui'
import VueFire from 'vuefire'
import { store } from './store'

import { MdButton, MdToolbar, MdCard, MdAvatar, MdBadge, MdTabs, MdSnackbar } from 'vue-material/dist/components'
import 'vue-material/dist/vue-material.min.css'
import 'vue-material/dist/theme/default.css'
import 'firebaseui/dist/firebaseui.css'
import 'material-design-icons/iconfont/material-icons.css'
import 'typeface-roboto'

Vue.use(VueFire)
Vue.use(MdToolbar)
Vue.use(MdButton)
Vue.use(MdCard)
Vue.use(MdAvatar)
Vue.use(MdBadge)
Vue.use(MdTabs)
Vue.use(MdSnackbar)

firebase.initializeApp({
  apiKey: '<YOUR_VALUE>',
  databaseURL: '<YOUR_VALUE>',
  storageBucket: '<YOUR_VALUE>',
  authDomain: '<YOUR_VALUE>',
  messagingSenderId: '<YOUR_VALUE>',
  projectId: '<YOUR_VALUE>'
})

export const db = firebase.firestore()
const settings = {timestampsInSnapshots: true}
db.settings(settings)

/* eslint-disable no-new */
const unsubscribe = firebase.auth().onAuthStateChanged((firebaseUser) => {
  new Vue({
    el: '#app',
    router,
    components: { App },
    template: '<App/>',
    store,
    // render: h => h(App),
    created () {
      if (firebaseUser) {
        store.dispatch('autoSignIn', firebaseUser)
      }
    }
  })
  unsubscribe()
})

Vue.config.productionTip = false
