import Vue from 'vue'
import Vuex from 'vuex'
import firebase from 'firebase/app'
import router from '@/router'

Vue.use(Vuex)

export const store = new Vuex.Store({
  state: {
    appTitle: 'Next Quiz Game',
    user: null,
    error: null,
    loading: false,
    photoURL: null
  },
  mutations: {
    setUser (state, payload) {
      state.user = payload
      if (payload !== null) {
        state.photoURL = payload.photoURL
        state.userId = payload.uid
      } else {
        state.photoURL = null
      }
    },
    setError (state, payload) {
      state.error = payload
    },
    setLoading (state, payload) {
      state.loading = payload
    }
  },
  actions: {
    autoSignIn ({ commit }, payload) {
      commit('setUser', payload)
    },
    userSignOut ({ commit }) {
      firebase.auth().signOut().then(function () {
        commit('setUser', null)
        router.push('/auth')
      }).catch(function (error) {
        console.error('Error while signing out: ' + error)
      })
    }
  },
  getters: {
    isAuthenticated (state) {
      return state.user !== null && state.user !== undefined
    },
    photoURL (state) {
      return state.user !== null ? state.user.photoURL : ''
    },
    userId (state) {
      return state.user !== null ? state.user.uid : ''
    }
  }
})
