import Vue from 'vue'
import Router from 'vue-router'
import Question from '@/components/Question'
import Auth from '@/components/Auth'
import AuthSuccess from '@/components/AuthSuccess'
import Dashboard from '@/components/Dashboard'
import End from '@/components/End'
import NotFound from '@/components/NotFound'
import firebase from 'firebase'

Vue.use(Router)

const router = new Router({
  // mode: 'history',
  routes: [
    {
      path: '/',
      redirect: '/question'
    },
    {
      path: '/the/end',
      name: 'the-end',
      component: End,
      meta: { requiresAuthentication: true }
    },
    {
      path: '/question',
      name: 'next-question',
      component: Question,
      meta: { requiresAuthentication: true }
    },
    {
      path: '/question/:id',
      name: 'question',
      component: Question,
      meta: { requiresAuthentication: true }
    },
    {
      path: '/auth',
      name: 'Authenticate',
      component: Auth
    },
    {
      path: '/success',
      name: 'AuthSuccess',
      component: AuthSuccess,
      meta: { requiresAuthentication: true }
    },
    {
      path: '/dashboard',
      name: 'Dashboard',
      component: Dashboard,
      meta: { requiresAuthentication: true }
    },
    {
      path: '*',
      name: 'NotFound',
      component: NotFound
    }
  ]
})

router.beforeEach((to, from, next) => {
  const requiresAuthentication = to.matched.some(record => record.meta.requiresAuthentication)
  const currentUser = firebase.auth().currentUser
  // console.log(`currentUser =  ${currentUser.uid}, currentUser === null: ${currentUser === null}`)
  if (requiresAuthentication && currentUser === null) {
    console.log('user is not authenticated.')
    next('/auth')
  } else {
    console.log('user is authenticated')
    next()
  }
})

export default router
