<template>
  <div id='app'>
    <md-toolbar class="md-transparent">
      <div class="md-toolbar-row">
        <div class="md-toolbar-section-start">
          <img src="./assets/GoogleNEXT18.png">
          <span class="md-title">Tech Trivia!</span>
        </div>
        <md-avatar class="md-alignment-top-right"><img v-if="this.$store.getters.photoURL" :src="this.$store.getters.photoURL"></md-avatar>
        <span class="md-subheading">&nbsp;{{lastSix}}&nbsp;</span>
        <md-button v-if="this.$store.getters.isAuthenticated" class="md-raised md-accent" @click="userSignOut">Sign Out</md-button>
      </div>
    </md-toolbar>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      user: {}
    }
  },
  computed: {
    appTitle () {
      return this.$store.state.appTitle
    },
    isAuthenticated () {
      return this.$store.getters.isAuthenticated
    },
    lastSix () {
      if (this.$store.getters.isAuthenticated) {
        return this.$store.getters.userId.slice(-6)
      }
    }
  },
  methods: {
    userSignOut () {
      this.$store.dispatch('userSignOut')
    }
  }
}
</script>

<style>
</style>
