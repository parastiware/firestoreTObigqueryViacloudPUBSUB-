
const PubSub = require('@google-cloud/pubsub');
const Firestore = require('@google-cloud/firestore');

const firestore = new Firestore({
    projectId: process.env.GCP_PROJECT,
});

// Converts strings added to /messages/{pushId}/original to uppercase
exports.makeUpperCase = (data, context) => {
    const { resource } = context;
    const affectedDoc = firestore.doc(resource.split('/documents/')[1]);

    const curValue = data.value.fields.original.stringValue;
    const newValue = curValue.toUpperCase();
    console.log(`Replacing value: ${curValue} --> ${newValue}`);

    return affectedDoc.set({
        original: newValue,
    });
};



const pubsubClient = new PubSub();

// Publish a message to Cloud Pub/Sub topic
// https://firebase.google.com/docs/functions/firestore-events
exports.publishMessageToTopic = functions.database.ref('users/{messageId}/newMsg/{newMsgId}').onWrite((snapshot, context) => {
    const msg = snapshot.val();
    const dataBuffer = Buffer.from(msg);

    // The name for the new topic
    const topicName = 'triviagameevents';

    // Creates the new topic
    return pubsubClient
        .topic(topicName)
        .publish(dataBuffer)
        .then(messageId => {
            console.log(`Message ${messageId} published.`);
            return messageId;
        })
        .catch(err => {
            console.error('ERROR:', err);
        });
});
